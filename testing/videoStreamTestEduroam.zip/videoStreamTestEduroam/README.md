Change wifi ssid and password in videostreamtest.ino. Confirmed works with cellular hotspot.
